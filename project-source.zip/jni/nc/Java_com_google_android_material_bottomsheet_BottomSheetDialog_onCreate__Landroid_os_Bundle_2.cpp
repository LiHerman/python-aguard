#include "Dex2C.h"

/* Lcom/google/android/material/bottomsheet/BottomSheetDialog;->onCreate(Landroid/os/Bundle;)V */
extern "C" JNIEXPORT void JNICALL
Java_com_google_android_material_bottomsheet_BottomSheetDialog_onCreate__Landroid_os_Bundle_2(JNIEnv *env, jobject thiz, jobject p4){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jint v4;
jint v5;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p4);
L0:
LOGD("0:invoke-super \x76\x33\x2c\x20\x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x69\x61\x6c\x6f\x67\x3b\x2d\x3e\x6f\x6e\x43\x72\x65\x61\x74\x65\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x6e\x64\x6c\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "androidx/appcompat/app/AppCompatDialog", "onCreate", "(Landroid/os/Bundle;)V");
jvalue args[] = {{.l = v1}};
env->CallNonvirtualVoidMethodA(v0, clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:invoke-virtual \x76\x33\x2c\x20\x4c\x63\x6f\x6d\x2f\x67\x6f\x6f\x67\x6c\x65\x2f\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6d\x61\x74\x65\x72\x69\x61\x6c\x2f\x62\x6f\x74\x74\x6f\x6d\x73\x68\x65\x65\x74\x2f\x42\x6f\x74\x74\x6f\x6d\x53\x68\x65\x65\x74\x44\x69\x61\x6c\x6f\x67\x3b\x2d\x3e\x67\x65\x74\x57\x69\x6e\x64\x6f\x77\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x57\x69\x6e\x64\x6f\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "com/google/android/material/bottomsheet/BottomSheetDialog", "getWindow", "()Landroid/view/Window;");
jvalue args[] = {};
v2 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c:move-result-object \x76\x30");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("e:if-eqz \x76\x30\x2c\x20\x2b\x31\x36");
if(v3 == NULL){
goto L4;
}
else {
goto L1;
}
L1:
LOGD("12:sget \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x69\x6c\x64\x24\x56\x45\x52\x53\x49\x4f\x4e\x3b\x2d\x3e\x53\x44\x4b\x5f\x49\x4e\x54\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls2;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "android/os/Build$VERSION", "SDK_INT", "I");
v4 = (jint) env->GetStaticIntField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v5 = 21;
LOGD("1a:if-lt \x76\x31\x2c\x20\x76\x32\x2c\x20\x2b\x63");
if(v4 < v5) {
goto L3;
}
else {
goto L2;
}
L2:
v4 = 67108864;
LOGD("22:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x57\x69\x6e\x64\x6f\x77\x3b\x2d\x3e\x63\x6c\x65\x61\x72\x46\x6c\x61\x67\x73\x28\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls3;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/view/Window", "clearFlags", "(I)V");
jvalue args[] = {{.i = v4}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v4 = -2147483648;
LOGD("2c:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x57\x69\x6e\x64\x6f\x77\x3b\x2d\x3e\x61\x64\x64\x46\x6c\x61\x67\x73\x28\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/view/Window", "addFlags", "(I)V");
jvalue args[] = {{.i = v4}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
v4 = -1;
LOGD("34:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x57\x69\x6e\x64\x6f\x77\x3b\x2d\x3e\x73\x65\x74\x4c\x61\x79\x6f\x75\x74\x28\x49\x20\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls3;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "android/view/Window", "setLayout", "(II)V");
jvalue args[] = {{.i = v4},{.i = v4}};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
return;
EX_UnwindBlock: return;
}
