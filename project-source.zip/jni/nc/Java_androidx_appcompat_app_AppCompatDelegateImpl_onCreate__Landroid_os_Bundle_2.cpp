#include "Dex2C.h"

/* Landroidx/appcompat/app/AppCompatDelegateImpl;->onCreate(Landroid/os/Bundle;)V */
extern "C" JNIEXPORT void JNICALL
Java_androidx_appcompat_app_AppCompatDelegateImpl_onCreate__Landroid_os_Bundle_2(JNIEnv *env, jobject thiz, jobject p4){
jobject v0 = NULL;
jobject v1 = NULL;
jint v2;
jint v3;
jint v4;
jobject v5 = NULL;
jobject v6 = NULL;
jint v7;
jobject v8 = NULL;
jthrowable exception;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p4);
L0:
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
LOGD("2:iput-boolean \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x65\x6c\x65\x67\x61\x74\x65\x49\x6d\x70\x6c\x3b\x2d\x3e\x6d\x42\x61\x73\x65\x43\x6f\x6e\x74\x65\x78\x74\x41\x74\x74\x61\x63\x68\x65\x64\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "androidx/appcompat/app/AppCompatDelegateImpl", "mBaseContextAttached", "Z");
env->SetBooleanField(v0,fld,(jboolean) v2);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v3 = 0;
LOGD("8:invoke-direct \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x65\x6c\x65\x67\x61\x74\x65\x49\x6d\x70\x6c\x3b\x2d\x3e\x61\x70\x70\x6c\x79\x44\x61\x79\x4e\x69\x67\x68\x74\x28\x5a\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "androidx/appcompat/app/AppCompatDelegateImpl", "applyDayNight", "(Z)Z");
jvalue args[] = {{.z = (jboolean) v3}};
v4 = (jboolean) env->CallBooleanMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("e:invoke-direct \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x65\x6c\x65\x67\x61\x74\x65\x49\x6d\x70\x6c\x3b\x2d\x3e\x65\x6e\x73\x75\x72\x65\x57\x69\x6e\x64\x6f\x77\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "androidx/appcompat/app/AppCompatDelegateImpl", "ensureWindow", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("14:iget-object \x76\x31\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x65\x6c\x65\x67\x61\x74\x65\x49\x6d\x70\x6c\x3b\x2d\x3e\x6d\x48\x6f\x73\x74\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld1;
D2C_RESOLVE_FIELD(clz, fld, "androidx/appcompat/app/AppCompatDelegateImpl", "mHost", "Ljava/lang/Object;");
v5 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v5;
LOGD("18:instance-of \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"android/app/Activity");
v7 = d2c_is_instance_of(env, v6, clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1c:if-eqz \x76\x32\x2c\x20\x2b\x31\x64");
if(v7 == 0){
goto L11;
}
else {
goto L1;
}
L1:
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = 0;
L2:
LOGD("22:check-cast \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b");
{
#define EX_HANDLE EX_LandingPad_2
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"android/app/Activity");
D2C_CHECK_CAST(v6, clz, "android/app/Activity");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L3:
LOGD("26:invoke-static \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x63\x6f\x72\x65\x2f\x61\x70\x70\x2f\x4e\x61\x76\x55\x74\x69\x6c\x73\x3b\x2d\x3e\x67\x65\x74\x50\x61\x72\x65\x6e\x74\x41\x63\x74\x69\x76\x69\x74\x79\x4e\x61\x6d\x65\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_LandingPad_2
jclass &clz = cls2;
jmethodID &mid = mth2;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "androidx/core/app/NavUtils", "getParentActivityName", "(Landroid/app/Activity;)Ljava/lang/String;");
jvalue args[] = {{.l = v6}};
v5 = (jstring) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("2c:move-result-object \x76\x31");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v5;
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewLocalRef(v6);
goto L6;
L5:
LOGD("32:move-exception \x76\x31");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = exception;
L6:
LOGD("34:if-eqz \x76\x32\x2c\x20\x2b\x65");
if(v8 == NULL){
goto L10;
}
else {
goto L7;
}
L7:
LOGD("38:invoke-virtual \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x65\x6c\x65\x67\x61\x74\x65\x49\x6d\x70\x6c\x3b\x2d\x3e\x70\x65\x65\x6b\x53\x75\x70\x70\x6f\x72\x74\x41\x63\x74\x69\x6f\x6e\x42\x61\x72\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x6f\x6e\x42\x61\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "androidx/appcompat/app/AppCompatDelegateImpl", "peekSupportActionBar", "()Landroidx/appcompat/app/ActionBar;");
jvalue args[] = {};
v5 = (jobject) env->CallObjectMethodA(v0, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3e:move-result-object \x76\x31");
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
v6 = (jobject) v5;
LOGD("40:if-nez \x76\x31\x2c\x20\x2b\x35");
if(v6 != NULL){
goto L9;
}
else {
goto L8;
}
L8:
LOGD("44:iput-boolean \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x65\x6c\x65\x67\x61\x74\x65\x49\x6d\x70\x6c\x3b\x2d\x3e\x6d\x45\x6e\x61\x62\x6c\x65\x44\x65\x66\x61\x75\x6c\x74\x41\x63\x74\x69\x6f\x6e\x42\x61\x72\x55\x70\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "androidx/appcompat/app/AppCompatDelegateImpl", "mEnableDefaultActionBarUp", "Z");
env->SetBooleanField(v0,fld,(jboolean) v2);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L10;
L9:
LOGD("4a:invoke-virtual \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x6f\x6e\x42\x61\x72\x3b\x2d\x3e\x73\x65\x74\x44\x65\x66\x61\x75\x6c\x74\x44\x69\x73\x70\x6c\x61\x79\x48\x6f\x6d\x65\x41\x73\x55\x70\x45\x6e\x61\x62\x6c\x65\x64\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
jclass &clz = cls3;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "androidx/appcompat/app/ActionBar", "setDefaultDisplayHomeAsUpEnabled", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v6, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L10:
LOGD("50:invoke-static \x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x65\x6c\x65\x67\x61\x74\x65\x49\x6d\x70\x6c\x3b\x2d\x3e\x61\x64\x64\x41\x63\x74\x69\x76\x65\x44\x65\x6c\x65\x67\x61\x74\x65\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x65\x6c\x65\x67\x61\x74\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls0;
jmethodID &mid = mth5;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "androidx/appcompat/app/AppCompatDelegateImpl", "addActiveDelegate", "(Landroidx/appcompat/app/AppCompatDelegate;)V");
jvalue args[] = {{.l = v0}};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L11:
LOGD("56:iput-boolean \x76\x30\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x65\x6c\x65\x67\x61\x74\x65\x49\x6d\x70\x6c\x3b\x2d\x3e\x6d\x43\x72\x65\x61\x74\x65\x64\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "androidx/appcompat/app/AppCompatDelegateImpl", "mCreated", "Z");
env->SetBooleanField(v0,fld,(jboolean) v2);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;

EX_LandingPad_2:
D2C_GET_PENDING_EX
if(d2c_is_instance_of(env, exception, "java/lang/IllegalArgumentException")) {
goto L5;
}
D2C_GOTO_UNWINDBLOCK
EX_UnwindBlock: return;
}
