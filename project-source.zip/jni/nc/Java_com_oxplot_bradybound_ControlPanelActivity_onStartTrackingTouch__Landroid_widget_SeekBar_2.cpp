#include "Dex2C.h"

/* Lcom/oxplot/bradybound/ControlPanelActivity;->onStartTrackingTouch(Landroid/widget/SeekBar;)V */
extern "C" JNIEXPORT void JNICALL
Java_com_oxplot_bradybound_ControlPanelActivity_onStartTrackingTouch__Landroid_widget_SeekBar_2(JNIEnv *env, jobject thiz, jobject p1){
jobject v0 = NULL;
jobject v1 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p1);
L0:
return;
EX_UnwindBlock: return;
}
