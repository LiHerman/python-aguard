#include "Dex2C.h"

/* Landroidx/appcompat/app/AlertDialog;->onCreate(Landroid/os/Bundle;)V */
extern "C" JNIEXPORT void JNICALL
Java_androidx_appcompat_app_AlertDialog_onCreate__Landroid_os_Bundle_2(JNIEnv *env, jobject thiz, jobject p2){
jobject v0 = NULL;
jobject v1 = NULL;
jobject v2 = NULL;
jobject v3 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL;
jfieldID fld0 = NULL;
jmethodID mth0 = NULL, mth1 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p2);
L0:
LOGD("0:invoke-super \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x70\x70\x43\x6f\x6d\x70\x61\x74\x44\x69\x61\x6c\x6f\x67\x3b\x2d\x3e\x6f\x6e\x43\x72\x65\x61\x74\x65\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x6f\x73\x2f\x42\x75\x6e\x64\x6c\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls0;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "androidx/appcompat/app/AppCompatDialog", "onCreate", "(Landroid/os/Bundle;)V");
jvalue args[] = {{.l = v1}};
env->CallNonvirtualVoidMethodA(v0, clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:iget-object \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x6c\x65\x72\x74\x44\x69\x61\x6c\x6f\x67\x3b\x2d\x3e\x6d\x41\x6c\x65\x72\x74\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x6c\x65\x72\x74\x43\x6f\x6e\x74\x72\x6f\x6c\x6c\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v0);
jclass &clz = cls1;
jfieldID &fld = fld0;
D2C_RESOLVE_FIELD(clz, fld, "androidx/appcompat/app/AlertDialog", "mAlert", "Landroidx/appcompat/app/AlertController;");
v2 = (jobject) env->GetObjectField(v0,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v2;
LOGD("a:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x78\x2f\x61\x70\x70\x63\x6f\x6d\x70\x61\x74\x2f\x61\x70\x70\x2f\x41\x6c\x65\x72\x74\x43\x6f\x6e\x74\x72\x6f\x6c\x6c\x65\x72\x3b\x2d\x3e\x69\x6e\x73\x74\x61\x6c\x6c\x43\x6f\x6e\x74\x65\x6e\x74\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "androidx/appcompat/app/AlertController", "installContent", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
