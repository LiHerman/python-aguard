#include "Dex2C.h"

/* Lcom/oxplot/bradybound/ControlPanelActivity;->onClick(Landroid/view/View;)V */
extern "C" JNIEXPORT void JNICALL
Java_com_oxplot_bradybound_ControlPanelActivity_onClick__Landroid_view_View_2(JNIEnv *env, jobject thiz, jobject p10){
jobject v0 = NULL;
jobject v1 = NULL;
jint v2;
jobject v3 = NULL;
jint v4;
jobject v5 = NULL;
jobject v6 = NULL;
jobject v7 = NULL;
jobject v8 = NULL;
jint v9;
jint v10;
jobject v11 = NULL;
jint v12;
jint v13;
jobject v14 = NULL;
jint v15;
jint v16;
jobject v17 = NULL;
jobject v18 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL,cls9 = NULL,cls10 = NULL,cls11 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL,fld4 = NULL,fld5 = NULL,fld6 = NULL,fld7 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p10);
L0:
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
LOGD("2:new-array \x76\x31\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v3 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v4 = 0;
v4 = 0;
v4 = 0;
v4 = 0;
v4 = 0;
v4 = 0;
v4 = 0;
v4 = 0;
v4 = 0;
v4 = 0;
v4 = 0;
LOGD("8:aput-object \x76\x31\x30\x2c\x20\x76\x31\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
env->SetObjectArrayElement((jobjectArray) v3, (jint) v4, v1);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c:sget-object \x76\x33\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x63\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls1;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "changeQuickRedirect", "Lcom/meituan/robust/ChangeQuickRedirect;");
v5 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("10:new-array \x76\x36\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/lang/Class");
v6 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("14:const-class \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77");
v7 = env->NewLocalRef(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("18:aput-object \x76\x32\x2c\x20\x76\x36\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
env->SetObjectArrayElement((jobjectArray) v6, (jint) v4, v7);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1c:sget-object \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x56\x6f\x69\x64\x3b\x2d\x3e\x54\x59\x50\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls4;
jfieldID &fld = fld1;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
v8 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v9 = 0;
v10 = 17;
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) env->NewLocalRef(v0);
LOGD("28:invoke-static/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x37\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x3b\x2d\x3e\x70\x72\x6f\x78\x79\x28\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b\x20\x5a\x20\x49\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x29\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls5;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "com/meituan/robust/PatchProxy", "proxy", "([Ljava/lang/Object;Ljava/lang/Object;Lcom/meituan/robust/ChangeQuickRedirect;ZI[Ljava/lang/Class;Ljava/lang/Class;)Lcom/meituan/robust/PatchProxyResult;");
jvalue args[] = {{.l = v3},{.l = v7},{.l = v5},{.z = (jboolean) v9},{.i = v10},{.l = v6},{.l = v8}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2e:move-result-object \x76\x31");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v11;
LOGD("30:iget-boolean \x76\x31\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b\x2d\x3e\x69\x73\x53\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls6;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "com/meituan/robust/PatchProxyResult", "isSupported", "Z");
v12 = (jboolean) env->GetBooleanField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("34:if-eqz \x76\x31\x2c\x20\x2b\x33");
if(v12 == 0){
goto L2;
}
else {
goto L1;
}
L1:
return;
L2:
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) env->NewLocalRef(v0);
LOGD("3c:iget-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "d", "Landroid/widget/Button;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v11;
v13 = 2131624037;
v13 = 2131624037;
LOGD("46:if-ne \x76\x31\x30\x2c\x20\x76\x32\x2c\x20\x2b\x35\x31");
if(!d2c_is_same_object(env,v1,v7)) {
goto L8;
}
else {
goto L3;
}
L3:
LOGD("4a:iget-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jfieldID &fld = fld4;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "g", "Landroid/content/SharedPreferences;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v11;
v9 = -1;
LOGD("50:const-string \x76\x35\x2c\x20\x27\x69\x6e\x62\x6f\x75\x6e\x64\x5f\x73\x70\x65\x65\x64\x27");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jstring) env->NewStringUTF("\x69\x6e\x62\x6f\x75\x6e\x64\x5f\x73\x70\x65\x65\x64");
LOGD("54:invoke-interface \x76\x32\x2c\x20\x76\x35\x2c\x20\x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x3b\x2d\x3e\x67\x65\x74\x49\x6e\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x49\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v7);
jclass &clz = cls7;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/content/SharedPreferences", "getInt", "(Ljava/lang/String;I)I");
jvalue args[] = {{.l = v14},{.i = v9}};
v15 = (jint) env->CallIntMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5a:move-result \x76\x32");
v16 = (jint) v15;
LOGD("5c:iget-object \x76\x34\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x68\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x42\x72\x61\x64\x79\x42\x6f\x75\x6e\x64\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "h", "Lcom/oxplot/bradybound/BradyBoundApplication;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v17) {
LOGD("env->DeleteLocalRef(%p):v17", v17);
env->DeleteLocalRef(v17);
}
v17 = (jobject) v11;
LOGD("60:invoke-virtual \x76\x34\x2c\x20\x76\x32\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x42\x72\x61\x64\x79\x42\x6f\x75\x6e\x64\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x3b\x2d\x3e\x61\x28\x49\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v17);
jclass &clz = cls8;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "com/oxplot/bradybound/BradyBoundApplication", "a", "(I)I");
jvalue args[] = {{.i = v16}};
v15 = (jint) env->CallIntMethodA(v17, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("66:move-result \x76\x34");
v9 = (jint) v15;
LOGD("68:if-nez \x76\x34\x2c\x20\x2b\x32\x62");
if(v9 != 0){
goto L5;
}
else {
goto L4;
}
L4:
LOGD("6c:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "d", "Landroid/widget/Button;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v11;
LOGD("70:invoke-virtual \x76\x33\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b\x2d\x3e\x73\x65\x74\x45\x6e\x61\x62\x6c\x65\x64\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls9;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Button", "setEnabled", "(Z)V");
jvalue args[] = {{.z = (jboolean) v4}};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("76:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "d", "Landroid/widget/Button;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v11;
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = 0;
LOGD("7c:invoke-virtual \x76\x33\x2c\x20\x76\x35\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b\x2d\x3e\x73\x65\x74\x54\x79\x70\x65\x66\x61\x63\x65\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x54\x79\x70\x65\x66\x61\x63\x65\x3b\x20\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls9;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Button", "setTypeface", "(Landroid/graphics/Typeface;I)V");
jvalue args[] = {{.l = v14},{.i = v4}};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("82:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "d", "Landroid/widget/Button;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v11;
LOGD("86:iget-object \x76\x35\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x63\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x72\x65\x73\x2f\x43\x6f\x6c\x6f\x72\x53\x74\x61\x74\x65\x4c\x69\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jfieldID &fld = fld6;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "c", "Landroid/content/res/ColorStateList;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v11;
LOGD("8a:invoke-virtual \x76\x33\x2c\x20\x76\x35\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b\x2d\x3e\x73\x65\x74\x54\x65\x78\x74\x43\x6f\x6c\x6f\x72\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x72\x65\x73\x2f\x43\x6f\x6c\x6f\x72\x53\x74\x61\x74\x65\x4c\x69\x73\x74\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls9;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Button", "setTextColor", "(Landroid/content/res/ColorStateList;)V");
jvalue args[] = {{.l = v14}};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v13 = 2131623982;
LOGD("96:new-array \x76\x30\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v18 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("9a:invoke-virtual \x76\x31\x2c\x20\x76\x32\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x63\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "com/oxplot/bradybound/ControlPanelActivity", "c", "(I)Ljava/lang/String;");
jvalue args[] = {{.i = v16}};
v11 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a0:move-result-object \x76\x35");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v11;
LOGD("a2:aput-object \x76\x35\x2c\x20\x76\x30\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
env->SetObjectArrayElement((jobjectArray) v18, (jint) v4, v14);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a6:invoke-virtual \x76\x31\x2c\x20\x76\x33\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x65\x74\x53\x74\x72\x69\x6e\x67\x28\x49\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls10;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "android/app/Activity", "getString", "(I[Ljava/lang/Object;)Ljava/lang/String;");
jvalue args[] = {{.i = v13},{.l = v18}};
v11 = (jstring) env->CallObjectMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("ac:move-result-object \x76\x30");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v11;
LOGD("ae:invoke-static \x76\x31\x2c\x20\x76\x30\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x6d\x61\x6b\x65\x54\x65\x78\x74\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x20\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls11;
jmethodID &mid = mth8;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/widget/Toast", "makeText", "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
jvalue args[] = {{.l = v3},{.l = v18},{.i = v4}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("b4:move-result-object \x76\x30");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v11;
LOGD("b6:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x68\x6f\x77\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls11;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "show", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L14;
L5:
LOGD("be:if-ne \x76\x34\x2c\x20\x76\x30\x2c\x20\x2b\x61");
if(v9 != v2) {
goto L7;
}
else {
goto L6;
}
L6:
LOGD("c2:invoke-static \x76\x31\x2c\x20\x76\x33\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x6d\x61\x6b\x65\x54\x65\x78\x74\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x49\x20\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls11;
jmethodID &mid = mth10;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/widget/Toast", "makeText", "(Landroid/content/Context;II)Landroid/widget/Toast;");
jvalue args[] = {{.l = v3},{.i = v13},{.i = v4}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c8:move-result-object \x76\x30");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v11;
LOGD("ca:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x68\x6f\x77\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls11;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "show", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L14;
L7:
v2 = 2131623981;
LOGD("d8:invoke-static \x76\x31\x2c\x20\x76\x30\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x6d\x61\x6b\x65\x54\x65\x78\x74\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x49\x20\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls11;
jmethodID &mid = mth10;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/widget/Toast", "makeText", "(Landroid/content/Context;II)Landroid/widget/Toast;");
jvalue args[] = {{.l = v3},{.i = v2},{.i = v4}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("de:move-result-object \x76\x30");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v11;
LOGD("e0:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x68\x6f\x77\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls11;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "show", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L14;
L8:
LOGD("e8:iget-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x65\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jfieldID &fld = fld7;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "e", "Landroid/widget/Button;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v11;
LOGD("ec:if-ne \x76\x31\x30\x2c\x20\x76\x32\x2c\x20\x2b\x32\x66");
if(!d2c_is_same_object(env,v1,v7)) {
goto L14;
}
else {
goto L9;
}
L9:
LOGD("f0:iget-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x68\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x42\x72\x61\x64\x79\x42\x6f\x75\x6e\x64\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "h", "Lcom/oxplot/bradybound/BradyBoundApplication;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v11;
LOGD("f4:invoke-virtual \x76\x32\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x42\x72\x61\x64\x79\x42\x6f\x75\x6e\x64\x41\x70\x70\x6c\x69\x63\x61\x74\x69\x6f\x6e\x3b\x2d\x3e\x61\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v7);
jclass &clz = cls8;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "com/oxplot/bradybound/BradyBoundApplication", "a", "()I");
jvalue args[] = {};
v15 = (jint) env->CallIntMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("fa:move-result \x76\x32");
v16 = (jint) v15;
LOGD("fc:if-nez \x76\x32\x2c\x20\x2b\x31\x32");
if(v16 != 0){
goto L11;
}
else {
goto L10;
}
L10:
LOGD("100:iget-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls1;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "d", "Landroid/widget/Button;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
v5 = (jobject) v11;
LOGD("104:invoke-virtual \x76\x33\x2c\x20\x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b\x2d\x3e\x73\x65\x74\x45\x6e\x61\x62\x6c\x65\x64\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
jclass &clz = cls9;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Button", "setEnabled", "(Z)V");
jvalue args[] = {{.z = (jboolean) v2}};
env->CallVoidMethodA(v5, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v2 = 2131623985;
LOGD("110:invoke-static \x76\x31\x2c\x20\x76\x30\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x6d\x61\x6b\x65\x54\x65\x78\x74\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x49\x20\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls11;
jmethodID &mid = mth10;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/widget/Toast", "makeText", "(Landroid/content/Context;II)Landroid/widget/Toast;");
jvalue args[] = {{.l = v3},{.i = v2},{.i = v4}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("116:move-result-object \x76\x30");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v11;
LOGD("118:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x68\x6f\x77\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls11;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "show", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L15;
L11:
LOGD("120:if-ne \x76\x32\x2c\x20\x76\x30\x2c\x20\x2b\x61");
if(v16 != v2) {
goto L13;
}
else {
goto L12;
}
L12:
LOGD("124:invoke-static \x76\x31\x2c\x20\x76\x33\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x6d\x61\x6b\x65\x54\x65\x78\x74\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x49\x20\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls11;
jmethodID &mid = mth10;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/widget/Toast", "makeText", "(Landroid/content/Context;II)Landroid/widget/Toast;");
jvalue args[] = {{.l = v3},{.i = v13},{.i = v4}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("12a:move-result-object \x76\x30");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v11;
LOGD("12c:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x68\x6f\x77\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls11;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "show", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L15;
L13:
v2 = 2131623984;
LOGD("13a:invoke-static \x76\x31\x2c\x20\x76\x30\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x6d\x61\x6b\x65\x54\x65\x78\x74\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x49\x20\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls11;
jmethodID &mid = mth10;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/widget/Toast", "makeText", "(Landroid/content/Context;II)Landroid/widget/Toast;");
jvalue args[] = {{.l = v3},{.i = v2},{.i = v4}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("140:move-result-object \x76\x30");
if (v18) {
LOGD("env->DeleteLocalRef(%p):v18", v18);
env->DeleteLocalRef(v18);
}
v18 = (jobject) v11;
LOGD("142:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x68\x6f\x77\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v18);
jclass &clz = cls11;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "show", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v18, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
goto L15;
L14:
L15:
return;
EX_UnwindBlock: return;
}
