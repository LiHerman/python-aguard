#include "Dex2C.h"

/* Lcom/oxplot/bradybound/ControlPanelActivity;->onShowPlugin(Landroid/view/View;)V */
extern "C" JNIEXPORT void JNICALL
Java_com_oxplot_bradybound_ControlPanelActivity_onShowPlugin__Landroid_view_View_2(JNIEnv *env, jobject thiz, jobject p10){
jobject v0 = NULL;
jobject v1 = NULL;
jint v2;
jobject v3 = NULL;
jint v4;
jobject v5 = NULL;
jobject v6 = NULL;
jobject v7 = NULL;
jobject v8 = NULL;
jint v9;
jint v10;
jobject v11 = NULL;
jobject v12 = NULL;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p10);
L0:
v2 = 1;
v2 = 1;
LOGD("2:new-array \x76\x31\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v3 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v4 = 0;
v4 = 0;
v4 = 0;
LOGD("8:aput-object \x76\x31\x30\x2c\x20\x76\x31\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
env->SetObjectArrayElement((jobjectArray) v3, (jint) v4, v1);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c:sget-object \x76\x33\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x63\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls1;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "changeQuickRedirect", "Lcom/meituan/robust/ChangeQuickRedirect;");
v5 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("10:new-array \x76\x36\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/lang/Class");
v6 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("14:const-class \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77\x3b");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"\x61\x6e\x64\x72\x6f\x69\x64\x2f\x76\x69\x65\x77\x2f\x56\x69\x65\x77");
v7 = env->NewLocalRef(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("18:aput-object \x76\x30\x2c\x20\x76\x36\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v6);
env->SetObjectArrayElement((jobjectArray) v6, (jint) v4, v7);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1c:sget-object \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x56\x6f\x69\x64\x3b\x2d\x3e\x54\x59\x50\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls4;
jfieldID &fld = fld1;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
v8 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v9 = 0;
v10 = 9;
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) env->NewLocalRef(v0);
LOGD("28:invoke-static/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x37\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x3b\x2d\x3e\x70\x72\x6f\x78\x79\x28\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b\x20\x5a\x20\x49\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x29\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls5;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "com/meituan/robust/PatchProxy", "proxy", "([Ljava/lang/Object;Ljava/lang/Object;Lcom/meituan/robust/ChangeQuickRedirect;ZI[Ljava/lang/Class;Ljava/lang/Class;)Lcom/meituan/robust/PatchProxyResult;");
jvalue args[] = {{.l = v3},{.l = v11},{.l = v5},{.z = (jboolean) v9},{.i = v10},{.l = v6},{.l = v8}};
v12 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2e:move-result-object \x76\x30");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v12;
LOGD("30:iget-boolean \x76\x30\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b\x2d\x3e\x69\x73\x53\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v7);
jclass &clz = cls6;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "com/meituan/robust/PatchProxyResult", "isSupported", "Z");
v2 = (jboolean) env->GetBooleanField(v7,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("34:if-eqz \x76\x30\x2c\x20\x2b\x33");
if(v2 == 0){
goto L2;
}
else {
goto L1;
}
L1:
return;
L2:
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) env->NewLocalRef(v0);
LOGD("3c:const-string \x76\x31\x2c\x20\x27\x6f\x72\x69\x67\x69\x6e\x61\x6c\x5f\x6f\x6e\x53\x68\x6f\x77\x50\x6c\x75\x67\x69\x6e\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) env->NewStringUTF("\x6f\x72\x69\x67\x69\x6e\x61\x6c\x5f\x6f\x6e\x53\x68\x6f\x77\x50\x6c\x75\x67\x69\x6e");
LOGD("40:invoke-static \x76\x30\x2c\x20\x76\x31\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x6d\x61\x6b\x65\x54\x65\x78\x74\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x43\x6f\x6e\x74\x65\x78\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x20\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls7;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "android/widget/Toast", "makeText", "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
jvalue args[] = {{.l = v7},{.l = v3},{.i = v4}};
v12 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("46:move-result-object \x76\x31");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v12;
LOGD("48:invoke-virtual \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x6f\x61\x73\x74\x3b\x2d\x3e\x73\x68\x6f\x77\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls7;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Toast", "show", "()V");
jvalue args[] = {};
env->CallVoidMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4e:invoke-static \x4c\x62\x2f\x63\x2f\x61\x2f\x61\x3b\x2d\x3e\x61\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls8;
jmethodID &mid = mth3;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "b/c/a/a", "a", "()V");
jvalue args[] = {};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("54:invoke-static \x4c\x62\x2f\x63\x2f\x61\x2f\x61\x3b\x2d\x3e\x62\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls8;
jmethodID &mid = mth4;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "b/c/a/a", "b", "()V");
jvalue args[] = {};
env->CallStaticVoidMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
