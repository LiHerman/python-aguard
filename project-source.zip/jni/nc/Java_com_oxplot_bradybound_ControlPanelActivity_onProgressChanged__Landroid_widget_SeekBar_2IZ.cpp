#include "Dex2C.h"

/* Lcom/oxplot/bradybound/ControlPanelActivity;->onProgressChanged(Landroid/widget/SeekBar;IZ)V */
extern "C" JNIEXPORT void JNICALL
Java_com_oxplot_bradybound_ControlPanelActivity_onProgressChanged__Landroid_widget_SeekBar_2IZ(JNIEnv *env, jobject thiz, jobject p10, jint p11, jboolean p12){
jobject v0 = NULL;
jobject v1 = NULL;
jint v2;
jint v3;
jint v4;
jobject v5 = NULL;
jint v6;
jobject v7 = NULL;
jint v8;
jint v9;
jobject v10 = NULL;
jobject v11 = NULL;
jobject v12 = NULL;
jint v13;
jobject v14 = NULL;
jobject v15 = NULL;
jint v16;
jint v17;
jint v18;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL,cls9 = NULL,cls10 = NULL,cls11 = NULL,cls12 = NULL,cls13 = NULL,cls14 = NULL,cls15 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL,fld4 = NULL,fld5 = NULL,fld6 = NULL,fld7 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL, mth11 = NULL, mth12 = NULL, mth13 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jobject)env->NewLocalRef(p10);
v2 = (jint)p11;
v3 = (jint)p12;
L0:
v4 = 3;
v4 = 3;
LOGD("2:new-array \x76\x31\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v4 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v5 = env->NewObjectArray((jint) v4, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v6 = 0;
v6 = 0;
LOGD("8:aput-object \x76\x31\x30\x2c\x20\x76\x31\x2c\x20\x76\x32");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
env->SetObjectArrayElement((jobjectArray) v5, (jint) v6, v1);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c:new-instance \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"java/lang/Integer");
v7 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("10:invoke-direct \x76\x33\x2c\x20\x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v7);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Integer", "<init>", "(I)V");
jvalue args[] = {{.i = v2}};
env->CallVoidMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v8 = 1;
v8 = 1;
v8 = 1;
v8 = 1;
LOGD("18:aput-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
env->SetObjectArrayElement((jobjectArray) v5, (jint) v8, v7);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1c:new-instance \x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x42\x79\x74\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/lang/Byte");
v7 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("20:invoke-direct \x76\x33\x2c\x20\x76\x31\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x42\x79\x74\x65\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x42\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v7);
jclass &clz = cls2;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Byte", "<init>", "(B)V");
jvalue args[] = {{.b = (jbyte) v3}};
env->CallVoidMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v9 = 2;
v9 = 2;
LOGD("28:aput-object \x76\x33\x2c\x20\x76\x31\x2c\x20\x76\x34");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v5);
env->SetObjectArrayElement((jobjectArray) v5, (jint) v9, v7);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("2c:sget-object \x76\x33\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x63\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
jclass &clz = cls3;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "changeQuickRedirect", "Lcom/meituan/robust/ChangeQuickRedirect;");
v7 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("30:new-array \x76\x36\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v4 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
jclass &clz = cls4;
D2C_RESOLVE_CLASS(clz,"java/lang/Class");
v10 = env->NewObjectArray((jint) v4, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("34:const-class \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x53\x65\x65\x6b\x42\x61\x72\x3b");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls5;
D2C_RESOLVE_CLASS(clz,"\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x53\x65\x65\x6b\x42\x61\x72");
v11 = env->NewLocalRef(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("38:aput-object \x76\x30\x2c\x20\x76\x36\x2c\x20\x76\x32");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
env->SetObjectArrayElement((jobjectArray) v10, (jint) v6, v11);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3c:sget-object \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x54\x59\x50\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
jclass &clz = cls1;
jfieldID &fld = fld1;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/lang/Integer", "TYPE", "Ljava/lang/Class;");
v11 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("40:aput-object \x76\x30\x2c\x20\x76\x36\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
env->SetObjectArrayElement((jobjectArray) v10, (jint) v8, v11);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("44:sget-object \x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x42\x6f\x6f\x6c\x65\x61\x6e\x3b\x2d\x3e\x54\x59\x50\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
jclass &clz = cls6;
jfieldID &fld = fld2;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/lang/Boolean", "TYPE", "Ljava/lang/Class;");
v11 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("48:aput-object \x76\x30\x2c\x20\x76\x36\x2c\x20\x76\x34");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
env->SetObjectArrayElement((jobjectArray) v10, (jint) v9, v11);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4c:sget-object \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x56\x6f\x69\x64\x3b\x2d\x3e\x54\x59\x50\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v12) {
LOGD("env->DeleteLocalRef(%p):v12", v12);
env->DeleteLocalRef(v12);
}
jclass &clz = cls7;
jfieldID &fld = fld3;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
v12 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v9 = 0;
v13 = 16;
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) env->NewLocalRef(v0);
LOGD("58:invoke-static/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x37\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x3b\x2d\x3e\x70\x72\x6f\x78\x79\x28\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b\x20\x5a\x20\x49\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x29\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls8;
jmethodID &mid = mth2;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "com/meituan/robust/PatchProxy", "proxy", "([Ljava/lang/Object;Ljava/lang/Object;Lcom/meituan/robust/ChangeQuickRedirect;ZI[Ljava/lang/Class;Ljava/lang/Class;)Lcom/meituan/robust/PatchProxyResult;");
jvalue args[] = {{.l = v5},{.l = v14},{.l = v7},{.z = (jboolean) v9},{.i = v13},{.l = v10},{.l = v12}};
v15 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5e:move-result-object \x76\x30");
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) v15;
LOGD("60:iget-boolean \x76\x30\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b\x2d\x3e\x69\x73\x53\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v11);
jclass &clz = cls9;
jfieldID &fld = fld4;
D2C_RESOLVE_FIELD(clz, fld, "com/meituan/robust/PatchProxyResult", "isSupported", "Z");
v4 = (jboolean) env->GetBooleanField(v11,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("64:if-eqz \x76\x30\x2c\x20\x2b\x33");
if(v4 == 0){
goto L2;
}
else {
goto L1;
}
L1:
return;
L2:
if (v11) {
LOGD("env->DeleteLocalRef(%p):v11", v11);
env->DeleteLocalRef(v11);
}
v11 = (jobject) env->NewLocalRef(v0);
LOGD("6c:invoke-virtual \x76\x30\x2c\x20\x76\x31\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x61\x28\x49\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v11);
jclass &clz = cls3;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "com/oxplot/bradybound/ControlPanelActivity", "a", "(I)I");
jvalue args[] = {{.i = v2}};
v16 = (jint) env->CallIntMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("72:move-result \x76\x31");
v17 = (jint) v16;
LOGD("74:iget-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x66\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x65\x78\x74\x56\x69\x65\x77\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v11);
jclass &clz = cls3;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "f", "Landroid/widget/TextView;");
v15 = (jobject) env->GetObjectField(v11,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v15;
LOGD("78:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x63\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v11);
jclass &clz = cls3;
jmethodID &mid = mth4;
D2C_RESOLVE_METHOD(clz, mid, "com/oxplot/bradybound/ControlPanelActivity", "c", "(I)Ljava/lang/String;");
jvalue args[] = {{.i = v17}};
v15 = (jstring) env->CallObjectMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("7e:move-result-object \x76\x33");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v15;
LOGD("80:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x54\x65\x78\x74\x56\x69\x65\x77\x3b\x2d\x3e\x73\x65\x74\x54\x65\x78\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x68\x61\x72\x53\x65\x71\x75\x65\x6e\x63\x65\x3b\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v14);
jclass &clz = cls10;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/TextView", "setText", "(Ljava/lang/CharSequence;)V");
jvalue args[] = {{.l = v7}};
env->CallVoidMethodA(v14, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("86:if-nez \x76\x31\x32\x2c\x20\x2b\x33");
if(v3 != 0){
goto L4;
}
else {
goto L3;
}
L3:
return;
L4:
LOGD("8c:iget-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v11);
jclass &clz = cls3;
jfieldID &fld = fld6;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "g", "Landroid/content/SharedPreferences;");
v15 = (jobject) env->GetObjectField(v11,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v15;
LOGD("90:invoke-interface \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x3b\x2d\x3e\x65\x64\x69\x74\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x24\x45\x64\x69\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v14);
jclass &clz = cls11;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "android/content/SharedPreferences", "edit", "()Landroid/content/SharedPreferences$Editor;");
jvalue args[] = {};
v15 = (jobject) env->CallObjectMethodA(v14, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("96:move-result-object \x76\x32");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v15;
LOGD("98:const-string \x76\x33\x2c\x20\x27\x69\x6e\x62\x6f\x75\x6e\x64\x5f\x73\x70\x65\x65\x64\x27");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jstring) env->NewStringUTF("\x69\x6e\x62\x6f\x75\x6e\x64\x5f\x73\x70\x65\x65\x64");
LOGD("9c:invoke-interface \x76\x32\x2c\x20\x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x24\x45\x64\x69\x74\x6f\x72\x3b\x2d\x3e\x70\x75\x74\x49\x6e\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x24\x45\x64\x69\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v14);
jclass &clz = cls12;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "android/content/SharedPreferences$Editor", "putInt", "(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;");
jvalue args[] = {{.l = v7},{.i = v17}};
v15 = (jobject) env->CallObjectMethodA(v14, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a2:move-result-object \x76\x32");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v15;
LOGD("a4:invoke-interface \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x24\x45\x64\x69\x74\x6f\x72\x3b\x2d\x3e\x63\x6f\x6d\x6d\x69\x74\x28\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v14);
jclass &clz = cls12;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "android/content/SharedPreferences$Editor", "commit", "()Z");
jvalue args[] = {};
v16 = (jboolean) env->CallBooleanMethodA(v14, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("aa:iget-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v11);
jclass &clz = cls3;
jfieldID &fld = fld7;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "d", "Landroid/widget/Button;");
v15 = (jobject) env->GetObjectField(v11,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v15;
LOGD("ae:invoke-virtual \x76\x32\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b\x2d\x3e\x73\x65\x74\x45\x6e\x61\x62\x6c\x65\x64\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v14);
jclass &clz = cls13;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Button", "setEnabled", "(Z)V");
jvalue args[] = {{.z = (jboolean) v8}};
env->CallVoidMethodA(v14, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("b4:iget-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v11);
jclass &clz = cls3;
jfieldID &fld = fld7;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "d", "Landroid/widget/Button;");
v15 = (jobject) env->GetObjectField(v11,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v15;
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = 0;
LOGD("ba:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x76\x38\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b\x2d\x3e\x73\x65\x74\x54\x79\x70\x65\x66\x61\x63\x65\x28\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x67\x72\x61\x70\x68\x69\x63\x73\x2f\x54\x79\x70\x65\x66\x61\x63\x65\x3b\x20\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v14);
jclass &clz = cls13;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Button", "setTypeface", "(Landroid/graphics/Typeface;I)V");
jvalue args[] = {{.l = v7},{.i = v8}};
env->CallVoidMethodA(v14, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c0:iget-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v11);
jclass &clz = cls3;
jfieldID &fld = fld7;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "d", "Landroid/widget/Button;");
v15 = (jobject) env->GetObjectField(v11,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v15;
LOGD("c4:invoke-virtual \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x65\x74\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x72\x65\x73\x2f\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v11);
jclass &clz = cls14;
jmethodID &mid = mth11;
D2C_RESOLVE_METHOD(clz, mid, "android/app/Activity", "getResources", "()Landroid/content/res/Resources;");
jvalue args[] = {};
v15 = (jobject) env->CallObjectMethodA(v11, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("ca:move-result-object \x76\x33");
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
v7 = (jobject) v15;
v9 = 2131034205;
LOGD("d2:invoke-virtual \x76\x33\x2c\x20\x76\x34\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x72\x65\x73\x2f\x52\x65\x73\x6f\x75\x72\x63\x65\x73\x3b\x2d\x3e\x67\x65\x74\x43\x6f\x6c\x6f\x72\x28\x49\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v7);
jclass &clz = cls15;
jmethodID &mid = mth12;
D2C_RESOLVE_METHOD(clz, mid, "android/content/res/Resources", "getColor", "(I)I");
jvalue args[] = {{.i = v9}};
v16 = (jint) env->CallIntMethodA(v7, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("d8:move-result \x76\x33");
v18 = (jint) v16;
LOGD("da:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b\x2d\x3e\x73\x65\x74\x54\x65\x78\x74\x43\x6f\x6c\x6f\x72\x28\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v14);
jclass &clz = cls13;
jmethodID &mid = mth13;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Button", "setTextColor", "(I)V");
jvalue args[] = {{.i = v18}};
env->CallVoidMethodA(v14, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
