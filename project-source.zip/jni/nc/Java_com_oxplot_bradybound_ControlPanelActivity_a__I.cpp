#include "Dex2C.h"

/* Lcom/oxplot/bradybound/ControlPanelActivity;->a(I)I */
extern "C" JNIEXPORT jint JNICALL
Java_com_oxplot_bradybound_ControlPanelActivity_a__I(JNIEnv *env, jobject thiz, jint p11){
jobject v0 = NULL;
jint v1;
jint v2;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jobject v6 = NULL;
jobject v7 = NULL;
jobject v8 = NULL;
jint v9;
jobject v10 = NULL;
jint v11;
jobject v12 = NULL;
jobject v13 = NULL;
jint v14;
jobject v15 = NULL;
jint v16;
jint v17;
jdouble v18;
jdouble v19;
jdouble v20;
jdouble v21;
jdouble v22;
jlong v23;
jlong v24;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL,fld4 = NULL,fld5 = NULL,fld6 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jint)p11;
L0:
v2 = 1;
v2 = 1;
LOGD("2:new-array \x76\x31\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v3 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:new-instance \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"java/lang/Integer");
v4 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:invoke-direct \x76\x32\x2c\x20\x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Integer", "<init>", "(I)V");
jvalue args[] = {{.i = v1}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v5 = 0;
v5 = 0;
LOGD("12:aput-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x76\x33");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
env->SetObjectArrayElement((jobjectArray) v3, (jint) v5, v4);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("16:sget-object \x76\x34\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x63\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls2;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "changeQuickRedirect", "Lcom/meituan/robust/ChangeQuickRedirect;");
v6 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1a:new-array \x76\x36\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"java/lang/Class");
v7 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1e:sget-object \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x54\x59\x50\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
jclass &clz = cls1;
jfieldID &fld = fld1;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/lang/Integer", "TYPE", "Ljava/lang/Class;");
v8 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("22:aput-object \x76\x37\x2c\x20\x76\x36\x2c\x20\x76\x33");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v7);
env->SetObjectArrayElement((jobjectArray) v7, (jint) v5, v8);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v2 = 0;
v9 = 14;
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) env->NewLocalRef(v0);
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) env->NewLocalRef(v6);
v11 = v2;
LOGD("32:invoke-static/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x37\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x3b\x2d\x3e\x70\x72\x6f\x78\x79\x28\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b\x20\x5a\x20\x49\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x29\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "com/meituan/robust/PatchProxy", "proxy", "([Ljava/lang/Object;Ljava/lang/Object;Lcom/meituan/robust/ChangeQuickRedirect;ZI[Ljava/lang/Class;Ljava/lang/Class;)Lcom/meituan/robust/PatchProxyResult;");
jvalue args[] = {{.l = v3},{.l = v4},{.l = v10},{.z = (jboolean) v11},{.i = v9},{.l = v7},{.l = v8}};
v12 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("38:move-result-object \x76\x30");
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v12;
LOGD("3a:iget-boolean \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b\x2d\x3e\x69\x73\x53\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "com/meituan/robust/PatchProxyResult", "isSupported", "Z");
v14 = (jboolean) env->GetBooleanField(v13,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3e:if-eqz \x76\x31\x2c\x20\x2b\x62");
if(v14 == 0){
goto L2;
}
else {
goto L1;
}
L1:
LOGD("42:iget-object \x76\x31\x31\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b\x2d\x3e\x72\x65\x73\x75\x6c\x74\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls5;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "com/meituan/robust/PatchProxyResult", "result", "Ljava/lang/Object;");
v12 = (jobject) env->GetObjectField(v13,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v15) {
LOGD("env->DeleteLocalRef(%p):v15", v15);
env->DeleteLocalRef(v15);
}
v15 = (jobject) v12;
LOGD("46:check-cast \x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"java/lang/Integer");
D2C_CHECK_CAST(v15, clz, "java/lang/Integer");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("4a:invoke-virtual \x76\x31\x31\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x69\x6e\x74\x56\x61\x6c\x75\x65\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v15);
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Integer", "intValue", "()I");
jvalue args[] = {};
v16 = (jint) env->CallIntMethodA(v15, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("50:move-result \x76\x31\x31");
v1 = (jint) v16;
return (jint) v1;
L2:
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) env->NewLocalRef(v0);
LOGD("56:iget-object \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x62\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x53\x65\x65\x6b\x42\x61\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls2;
jfieldID &fld = fld4;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "b", "Landroid/widget/SeekBar;");
v12 = (jobject) env->GetObjectField(v13,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v12;
LOGD("5a:invoke-virtual \x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x53\x65\x65\x6b\x42\x61\x72\x3b\x2d\x3e\x67\x65\x74\x4d\x61\x78\x28\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls6;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/SeekBar", "getMax", "()I");
jvalue args[] = {};
v16 = (jint) env->CallIntMethodA(v3, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("60:move-result \x76\x31");
v14 = (jint) v16;
LOGD("62:iget \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x6a\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls2;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "j", "I");
v17 = (jint) env->GetIntField(v13,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("66:iget \x76\x33\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x69\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls2;
jfieldID &fld = fld6;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "i", "I");
v5 = (jint) env->GetIntField(v13,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6a:sub-int/2addr \x76\x32\x2c\x20\x76\x33");
v17 = (v17 - v5);
LOGD("6c:add-int/lit8 \x76\x32\x2c\x20\x76\x32\x2c\x20\x31\x30");
v17 = (v17 + 10);
v18 = (jdouble)(v17);
LOGD("72:invoke-static \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4d\x61\x74\x68\x3b\x2d\x3e\x6c\x6f\x67\x31\x30\x28\x44\x29\x44");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls7;
jmethodID &mid = mth4;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Math", "log10", "(D)D");
jvalue args[] = {{.d = v18}};
v19 = (jdouble) env->CallStaticDoubleMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("78:move-result-wide \x76\x32");
v18 = (jdouble) v19;
v20 = d2c_bitcast_to_double(4607182418800017408);
v20 = d2c_bitcast_to_double(4607182418800017408);
LOGD("7e:sub-double/2addr \x76\x32\x2c\x20\x76\x34");
v18 = (v18 - v20);
v21 = (jdouble)(v1);
LOGD("82:mul-double \x76\x36\x2c\x20\x76\x36\x2c\x20\x76\x32");
v21 = (v21 * v18);
v22 = (jdouble)(v14);
LOGD("88:div-double/2addr \x76\x36\x2c\x20\x76\x38");
{
v21 = v21 / v22;
}
LOGD("8a:add-double/2addr \x76\x36\x2c\x20\x76\x34");
v21 = (v21 + v20);
v20 = d2c_bitcast_to_double(4621819117588971520);
v20 = d2c_bitcast_to_double(4621819117588971520);
LOGD("90:invoke-static \x76\x34\x2c\x20\x76\x35\x2c\x20\x76\x36\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4d\x61\x74\x68\x3b\x2d\x3e\x70\x6f\x77\x28\x44\x20\x44\x29\x44");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls7;
jmethodID &mid = mth5;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Math", "pow", "(DD)D");
jvalue args[] = {{.d = v20},{.d = v21}};
v19 = (jdouble) env->CallStaticDoubleMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("96:move-result-wide \x76\x36");
v21 = (jdouble) v19;
LOGD("98:sub-double/2addr \x76\x36\x2c\x20\x76\x34");
v21 = (v21 - v20);
LOGD("9a:iget \x76\x34\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x69\x20\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v13);
jclass &clz = cls2;
jfieldID &fld = fld6;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "i", "I");
v11 = (jint) env->GetIntField(v13,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v20 = (jdouble)(v11);
LOGD("a0:add-double/2addr \x76\x36\x2c\x20\x76\x34");
v21 = (v21 + v20);
LOGD("a2:invoke-static \x76\x36\x2c\x20\x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4d\x61\x74\x68\x3b\x2d\x3e\x72\x6f\x75\x6e\x64\x28\x44\x29\x4a");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls7;
jmethodID &mid = mth6;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Math", "round", "(D)J");
jvalue args[] = {{.d = v21}};
v23 = (jlong) env->CallStaticLongMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a8:move-result-wide \x76\x34");
v24 = (jlong) v23;
v9 = (jint)(v24);
return (jint) v9;
EX_UnwindBlock: return (jint)0;
}
