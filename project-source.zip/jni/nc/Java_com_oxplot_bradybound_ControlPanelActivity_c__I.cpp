#include "Dex2C.h"

/* Lcom/oxplot/bradybound/ControlPanelActivity;->c(I)Ljava/lang/String; */
extern "C" JNIEXPORT jstring JNICALL
Java_com_oxplot_bradybound_ControlPanelActivity_c__I(JNIEnv *env, jobject thiz, jint p10){
jobject v0 = NULL;
jint v1;
jint v2;
jobject v3 = NULL;
jobject v4 = NULL;
jint v5;
jobject v6 = NULL;
jobject v7 = NULL;
jobject v8 = NULL;
jint v9;
jint v10;
jobject v11 = NULL;
jint v12;
jobject v13 = NULL;
jobject v14 = NULL;
jdouble v15;
jdouble v16;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
v1 = (jint)p10;
L0:
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
v2 = 1;
LOGD("2:new-array \x76\x31\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v3 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:new-instance \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
jclass &clz = cls1;
D2C_RESOLVE_CLASS(clz,"java/lang/Integer");
v4 = (jobject) env->AllocObject(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:invoke-direct \x76\x32\x2c\x20\x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x3c\x69\x6e\x69\x74\x3e\x28\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v4);
jclass &clz = cls1;
jmethodID &mid = mth0;
D2C_RESOLVE_METHOD(clz, mid, "java/lang/Integer", "<init>", "(I)V");
jvalue args[] = {{.i = v1}};
env->CallVoidMethodA(v4, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v5 = 0;
v5 = 0;
v5 = 0;
v5 = 0;
v5 = 0;
LOGD("12:aput-object \x76\x32\x2c\x20\x76\x31\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
env->SetObjectArrayElement((jobjectArray) v3, (jint) v5, v4);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("16:sget-object \x76\x33\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x63\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v6) {
LOGD("env->DeleteLocalRef(%p):v6", v6);
env->DeleteLocalRef(v6);
}
jclass &clz = cls2;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "changeQuickRedirect", "Lcom/meituan/robust/ChangeQuickRedirect;");
v6 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1a:new-array \x76\x36\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v7) {
LOGD("env->DeleteLocalRef(%p):v7", v7);
env->DeleteLocalRef(v7);
}
jclass &clz = cls3;
D2C_RESOLVE_CLASS(clz,"java/lang/Class");
v7 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("1e:sget-object \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x54\x59\x50\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
jclass &clz = cls1;
jfieldID &fld = fld1;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/lang/Integer", "TYPE", "Ljava/lang/Class;");
v4 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("22:aput-object \x76\x32\x2c\x20\x76\x36\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v7);
env->SetObjectArrayElement((jobjectArray) v7, (jint) v5, v4);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("26:const-class \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
D2C_RESOLVE_CLASS(clz,"\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67");
v8 = env->NewLocalRef(clz);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v9 = 0;
v10 = 15;
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) env->NewLocalRef(v0);
LOGD("32:invoke-static/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x37\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x3b\x2d\x3e\x70\x72\x6f\x78\x79\x28\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b\x20\x5a\x20\x49\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x29\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls5;
jmethodID &mid = mth1;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "com/meituan/robust/PatchProxy", "proxy", "([Ljava/lang/Object;Ljava/lang/Object;Lcom/meituan/robust/ChangeQuickRedirect;ZI[Ljava/lang/Class;Ljava/lang/Class;)Lcom/meituan/robust/PatchProxyResult;");
jvalue args[] = {{.l = v3},{.l = v4},{.l = v6},{.z = (jboolean) v9},{.i = v10},{.l = v7},{.l = v8}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("38:move-result-object \x76\x31");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) v11;
LOGD("3a:iget-boolean \x76\x32\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b\x2d\x3e\x69\x73\x53\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls6;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "com/meituan/robust/PatchProxyResult", "isSupported", "Z");
v12 = (jboolean) env->GetBooleanField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("3e:if-eqz \x76\x32\x2c\x20\x2b\x37");
if(v12 == 0){
goto L2;
}
else {
goto L1;
}
L1:
LOGD("42:iget-object \x76\x31\x30\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b\x2d\x3e\x72\x65\x73\x75\x6c\x74\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v3);
jclass &clz = cls6;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "com/meituan/robust/PatchProxyResult", "result", "Ljava/lang/Object;");
v11 = (jobject) env->GetObjectField(v3,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v13) {
LOGD("env->DeleteLocalRef(%p):v13", v13);
env->DeleteLocalRef(v13);
}
v13 = (jobject) v11;
LOGD("46:check-cast \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls7;
D2C_RESOLVE_CLASS(clz,"java/lang/String");
D2C_CHECK_CAST(v13, clz, "java/lang/String");
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return (jstring) v13;
L2:
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jobject) env->NewLocalRef(v0);
v12 = 1000;
LOGD("52:if-ge \x76\x31\x30\x2c\x20\x76\x32\x2c\x20\x2b\x31\x31");
if(v1 >= v12) {
goto L4;
}
else {
goto L3;
}
L3:
LOGD("56:new-array \x76\x30\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v14 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5a:invoke-static \x76\x31\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x76\x61\x6c\x75\x65\x4f\x66\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;");
jvalue args[] = {{.i = v1}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("60:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v11;
LOGD("62:aput-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v14);
env->SetObjectArrayElement((jobjectArray) v14, (jint) v5, v4);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("66:const-string \x76\x32\x2c\x20\x27\x25\x64\x20\x4b\x42\x2f\x73\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x25\x64\x20\x4b\x42\x2f\x73");
LOGD("6a:invoke-static \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x66\x6f\x72\x6d\x61\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls7;
jmethodID &mid = mth3;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/String", "format", "(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;");
jvalue args[] = {{.l = v4},{.l = v14}};
v11 = (jstring) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("70:move-result-object \x76\x30");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v11;
return (jstring) v14;
L4:
v12 = 10000;
LOGD("78:if-ge \x76\x31\x30\x2c\x20\x76\x32\x2c\x20\x2b\x31\x38");
if(v1 >= v12) {
goto L6;
}
else {
goto L5;
}
L5:
LOGD("7c:new-array \x76\x30\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v14 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v15 = (jdouble)(v1);
v16 = d2c_bitcast_to_double(4652007308841189376);
LOGD("8c:div-double/2addr \x76\x32\x2c\x20\x76\x34");
{
v15 = v15 / v16;
}
LOGD("8e:invoke-static \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x44\x6f\x75\x62\x6c\x65\x3b\x2d\x3e\x76\x61\x6c\x75\x65\x4f\x66\x28\x44\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x44\x6f\x75\x62\x6c\x65\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls8;
jmethodID &mid = mth4;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Double", "valueOf", "(D)Ljava/lang/Double;");
jvalue args[] = {{.d = v15}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("94:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v11;
LOGD("96:aput-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v14);
env->SetObjectArrayElement((jobjectArray) v14, (jint) v5, v4);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("9a:const-string \x76\x32\x2c\x20\x27\x25\x2e\x31\x66\x20\x4d\x42\x2f\x73\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x25\x2e\x31\x66\x20\x4d\x42\x2f\x73");
LOGD("9e:invoke-static \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x66\x6f\x72\x6d\x61\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls7;
jmethodID &mid = mth3;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/String", "format", "(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;");
jvalue args[] = {{.l = v4},{.l = v14}};
v11 = (jstring) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a4:move-result-object \x76\x30");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v11;
return (jstring) v14;
L6:
LOGD("a8:new-array \x76\x30\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v2 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v14 = env->NewObjectArray((jint) v2, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("ac:div-int/lit16 \x76\x32\x2c\x20\x76\x31\x30\x2c\x20\x31\x30\x30\x30");
{
#define EX_HANDLE EX_UnwindBlock
if (1000 == 0) {
d2c_throw_exception(env, "java/lang/ArithmeticException", "divide by zero");
goto EX_HANDLE;
}
#undef EX_HANDLE
v12 = v1 / 1000;
}
LOGD("b0:invoke-static \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x76\x61\x6c\x75\x65\x4f\x66\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls1;
jmethodID &mid = mth2;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Integer", "valueOf", "(I)Ljava/lang/Integer;");
jvalue args[] = {{.i = v12}};
v11 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("b6:move-result-object \x76\x32");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jobject) v11;
LOGD("b8:aput-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x76\x38");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v14);
env->SetObjectArrayElement((jobjectArray) v14, (jint) v5, v4);D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("bc:const-string \x76\x32\x2c\x20\x27\x25\x64\x20\x4d\x42\x2f\x73\x27");
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
v4 = (jstring) env->NewStringUTF("\x25\x64\x20\x4d\x42\x2f\x73");
LOGD("c0:invoke-static \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x2d\x3e\x66\x6f\x72\x6d\x61\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls7;
jmethodID &mid = mth3;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/String", "format", "(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;");
jvalue args[] = {{.l = v4},{.l = v14}};
v11 = (jstring) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("c6:move-result-object \x76\x30");
if (v14) {
LOGD("env->DeleteLocalRef(%p):v14", v14);
env->DeleteLocalRef(v14);
}
v14 = (jobject) v11;
return (jstring) v14;
EX_UnwindBlock: return NULL;
}
