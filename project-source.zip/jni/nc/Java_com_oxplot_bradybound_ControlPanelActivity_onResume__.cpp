#include "Dex2C.h"

/* Lcom/oxplot/bradybound/ControlPanelActivity;->onResume()V */
extern "C" JNIEXPORT void JNICALL
Java_com_oxplot_bradybound_ControlPanelActivity_onResume__(JNIEnv *env, jobject thiz){
jobject v0 = NULL;
jint v1;
jobject v2 = NULL;
jobject v3 = NULL;
jobject v4 = NULL;
jobject v5 = NULL;
jint v6;
jint v7;
jobject v8 = NULL;
jobject v9 = NULL;
jobject v10 = NULL;
jint v11;
jint v12;
jint v13;
jint v14;
jclass cls0 = NULL,cls1 = NULL,cls2 = NULL,cls3 = NULL,cls4 = NULL,cls5 = NULL,cls6 = NULL,cls7 = NULL,cls8 = NULL,cls9 = NULL,cls10 = NULL,cls11 = NULL;
jfieldID fld0 = NULL,fld1 = NULL,fld2 = NULL,fld3 = NULL,fld4 = NULL,fld5 = NULL;
jmethodID mth0 = NULL, mth1 = NULL, mth2 = NULL, mth3 = NULL, mth4 = NULL, mth5 = NULL, mth6 = NULL, mth7 = NULL, mth8 = NULL, mth9 = NULL, mth10 = NULL;
v0 = (jobject)env->NewLocalRef(thiz);
L0:
v1 = 0;
v1 = 0;
LOGD("2:new-array \x76\x31\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v1 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
jclass &clz = cls0;
D2C_RESOLVE_CLASS(clz,"java/lang/Object");
v2 = env->NewObjectArray((jint) v1, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6:sget-object \x76\x33\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x63\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
jclass &clz = cls1;
jfieldID &fld = fld0;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "changeQuickRedirect", "Lcom/meituan/robust/ChangeQuickRedirect;");
v3 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("a:new-array \x76\x36\x2c\x20\x76\x30\x2c\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v1 < 0) {
d2c_throw_exception(env, "java/lang/NegativeArraySizeException", "negative array size");
goto EX_HANDLE;
}
if (v4) {
LOGD("env->DeleteLocalRef(%p):v4", v4);
env->DeleteLocalRef(v4);
}
jclass &clz = cls2;
D2C_RESOLVE_CLASS(clz,"java/lang/Class");
v4 = env->NewObjectArray((jint) v1, clz, NULL);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("e:sget-object \x76\x37\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x56\x6f\x69\x64\x3b\x2d\x3e\x54\x59\x50\x45\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
if (v5) {
LOGD("env->DeleteLocalRef(%p):v5", v5);
env->DeleteLocalRef(v5);
}
jclass &clz = cls3;
jfieldID &fld = fld1;
D2C_RESOLVE_STATIC_FIELD(clz, fld, "java/lang/Void", "TYPE", "Ljava/lang/Class;");
v5 = (jobject) env->GetStaticObjectField(clz,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
v6 = 0;
v7 = 12;
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) env->NewLocalRef(v0);
LOGD("1a:invoke-static/range \x76\x31\x20\x2e\x2e\x2e\x20\x76\x37\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x3b\x2d\x3e\x70\x72\x6f\x78\x79\x28\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x4f\x62\x6a\x65\x63\x74\x3b\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x43\x68\x61\x6e\x67\x65\x51\x75\x69\x63\x6b\x52\x65\x64\x69\x72\x65\x63\x74\x3b\x20\x5a\x20\x49\x20\x5b\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x43\x6c\x61\x73\x73\x3b\x29\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls4;
jmethodID &mid = mth0;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "com/meituan/robust/PatchProxy", "proxy", "([Ljava/lang/Object;Ljava/lang/Object;Lcom/meituan/robust/ChangeQuickRedirect;ZI[Ljava/lang/Class;Ljava/lang/Class;)Lcom/meituan/robust/PatchProxyResult;");
jvalue args[] = {{.l = v2},{.l = v8},{.l = v3},{.z = (jboolean) v6},{.i = v7},{.l = v4},{.l = v5}};
v9 = (jobject) env->CallStaticObjectMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("20:move-result-object \x76\x30");
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) v9;
LOGD("22:iget-boolean \x76\x30\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6d\x65\x69\x74\x75\x61\x6e\x2f\x72\x6f\x62\x75\x73\x74\x2f\x50\x61\x74\x63\x68\x50\x72\x6f\x78\x79\x52\x65\x73\x75\x6c\x74\x3b\x2d\x3e\x69\x73\x53\x75\x70\x70\x6f\x72\x74\x65\x64\x20\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls5;
jfieldID &fld = fld2;
D2C_RESOLVE_FIELD(clz, fld, "com/meituan/robust/PatchProxyResult", "isSupported", "Z");
v1 = (jboolean) env->GetBooleanField(v10,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("26:if-eqz \x76\x30\x2c\x20\x2b\x33");
if(v1 == 0){
goto L2;
}
else {
goto L1;
}
L1:
return;
L2:
if (v10) {
LOGD("env->DeleteLocalRef(%p):v10", v10);
env->DeleteLocalRef(v10);
}
v10 = (jobject) env->NewLocalRef(v0);
LOGD("2e:invoke-super \x76\x30\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x6f\x6e\x52\x65\x73\x75\x6d\x65\x28\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls6;
jmethodID &mid = mth1;
D2C_RESOLVE_METHOD(clz, mid, "android/app/Activity", "onResume", "()V");
jvalue args[] = {};
env->CallNonvirtualVoidMethodA(v10, clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("34:iget-object \x76\x31\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls1;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "g", "Landroid/content/SharedPreferences;");
v9 = (jobject) env->GetObjectField(v10,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v2) {
LOGD("env->DeleteLocalRef(%p):v2", v2);
env->DeleteLocalRef(v2);
}
v2 = (jobject) v9;
v11 = -1;
v11 = -1;
LOGD("3a:const-string \x76\x33\x2c\x20\x27\x69\x6e\x62\x6f\x75\x6e\x64\x5f\x73\x70\x65\x65\x64\x27");
if (v3) {
LOGD("env->DeleteLocalRef(%p):v3", v3);
env->DeleteLocalRef(v3);
}
v3 = (jstring) env->NewStringUTF("\x69\x6e\x62\x6f\x75\x6e\x64\x5f\x73\x70\x65\x65\x64");
LOGD("3e:invoke-interface \x76\x31\x2c\x20\x76\x33\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x3b\x2d\x3e\x67\x65\x74\x49\x6e\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x49\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v2);
jclass &clz = cls7;
jmethodID &mid = mth2;
D2C_RESOLVE_METHOD(clz, mid, "android/content/SharedPreferences", "getInt", "(Ljava/lang/String;I)I");
jvalue args[] = {{.l = v3},{.i = v11}};
v12 = (jint) env->CallIntMethodA(v2, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("44:move-result \x76\x31");
v13 = (jint) v12;
LOGD("46:if-ne \x76\x31\x2c\x20\x76\x32\x2c\x20\x2b\x31\x61");
if(v13 != v11) {
goto L4;
}
else {
goto L3;
}
L3:
v11 = 2131623972;
LOGD("50:invoke-virtual \x76\x30\x2c\x20\x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x61\x70\x70\x2f\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x65\x74\x53\x74\x72\x69\x6e\x67\x28\x49\x29\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls6;
jmethodID &mid = mth3;
D2C_RESOLVE_METHOD(clz, mid, "android/app/Activity", "getString", "(I)Ljava/lang/String;");
jvalue args[] = {{.i = v11}};
v9 = (jstring) env->CallObjectMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("56:move-result-object \x76\x32");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v9;
LOGD("58:invoke-static \x76\x32\x2c\x20\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x49\x6e\x74\x65\x67\x65\x72\x3b\x2d\x3e\x70\x61\x72\x73\x65\x49\x6e\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
jclass &clz = cls8;
jmethodID &mid = mth4;
D2C_RESOLVE_STATIC_METHOD(clz, mid, "java/lang/Integer", "parseInt", "(Ljava/lang/String;)I");
jvalue args[] = {{.l = v8}};
v12 = (jint) env->CallStaticIntMethodA(clz, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("5e:move-result \x76\x31");
v13 = (jint) v12;
LOGD("60:iget-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x67\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls1;
jfieldID &fld = fld3;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "g", "Landroid/content/SharedPreferences;");
v9 = (jobject) env->GetObjectField(v10,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v9;
LOGD("64:invoke-interface \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x3b\x2d\x3e\x65\x64\x69\x74\x28\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x24\x45\x64\x69\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls7;
jmethodID &mid = mth5;
D2C_RESOLVE_METHOD(clz, mid, "android/content/SharedPreferences", "edit", "()Landroid/content/SharedPreferences$Editor;");
jvalue args[] = {};
v9 = (jobject) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("6a:move-result-object \x76\x32");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v9;
LOGD("6c:invoke-interface \x76\x32\x2c\x20\x76\x33\x2c\x20\x76\x31\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x24\x45\x64\x69\x74\x6f\x72\x3b\x2d\x3e\x70\x75\x74\x49\x6e\x74\x28\x4c\x6a\x61\x76\x61\x2f\x6c\x61\x6e\x67\x2f\x53\x74\x72\x69\x6e\x67\x3b\x20\x49\x29\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x24\x45\x64\x69\x74\x6f\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls9;
jmethodID &mid = mth6;
D2C_RESOLVE_METHOD(clz, mid, "android/content/SharedPreferences$Editor", "putInt", "(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;");
jvalue args[] = {{.l = v3},{.i = v13}};
v9 = (jobject) env->CallObjectMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("72:move-result-object \x76\x32");
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v9;
LOGD("74:invoke-interface \x76\x32\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x53\x68\x61\x72\x65\x64\x50\x72\x65\x66\x65\x72\x65\x6e\x63\x65\x73\x24\x45\x64\x69\x74\x6f\x72\x3b\x2d\x3e\x63\x6f\x6d\x6d\x69\x74\x28\x29\x5a");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls9;
jmethodID &mid = mth7;
D2C_RESOLVE_METHOD(clz, mid, "android/content/SharedPreferences$Editor", "commit", "()Z");
jvalue args[] = {};
v12 = (jboolean) env->CallBooleanMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
L4:
LOGD("7a:iget-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x62\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x53\x65\x65\x6b\x42\x61\x72\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls1;
jfieldID &fld = fld4;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "b", "Landroid/widget/SeekBar;");
v9 = (jobject) env->GetObjectField(v10,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v9;
LOGD("7e:invoke-virtual \x76\x30\x2c\x20\x76\x31\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x62\x28\x49\x29\x49");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls1;
jmethodID &mid = mth8;
D2C_RESOLVE_METHOD(clz, mid, "com/oxplot/bradybound/ControlPanelActivity", "b", "(I)I");
jvalue args[] = {{.i = v13}};
v12 = (jint) env->CallIntMethodA(v10, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("84:move-result \x76\x33");
v14 = (jint) v12;
LOGD("86:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x53\x65\x65\x6b\x42\x61\x72\x3b\x2d\x3e\x73\x65\x74\x50\x72\x6f\x67\x72\x65\x73\x73\x28\x49\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls10;
jmethodID &mid = mth9;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/SeekBar", "setProgress", "(I)V");
jvalue args[] = {{.i = v14}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
LOGD("8c:iget-object \x76\x32\x2c\x20\x76\x30\x2c\x20\x4c\x63\x6f\x6d\x2f\x6f\x78\x70\x6c\x6f\x74\x2f\x62\x72\x61\x64\x79\x62\x6f\x75\x6e\x64\x2f\x43\x6f\x6e\x74\x72\x6f\x6c\x50\x61\x6e\x65\x6c\x41\x63\x74\x69\x76\x69\x74\x79\x3b\x2d\x3e\x64\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v10);
jclass &clz = cls1;
jfieldID &fld = fld5;
D2C_RESOLVE_FIELD(clz, fld, "com/oxplot/bradybound/ControlPanelActivity", "d", "Landroid/widget/Button;");
v9 = (jobject) env->GetObjectField(v10,fld);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
if (v8) {
LOGD("env->DeleteLocalRef(%p):v8", v8);
env->DeleteLocalRef(v8);
}
v8 = (jobject) v9;
v14 = 1;
LOGD("92:invoke-virtual \x76\x32\x2c\x20\x76\x33\x2c\x20\x4c\x61\x6e\x64\x72\x6f\x69\x64\x2f\x77\x69\x64\x67\x65\x74\x2f\x42\x75\x74\x74\x6f\x6e\x3b\x2d\x3e\x73\x65\x74\x45\x6e\x61\x62\x6c\x65\x64\x28\x5a\x29\x56");
{
#define EX_HANDLE EX_UnwindBlock
D2C_NOT_NULL(v8);
jclass &clz = cls11;
jmethodID &mid = mth10;
D2C_RESOLVE_METHOD(clz, mid, "android/widget/Button", "setEnabled", "(Z)V");
jvalue args[] = {{.z = (jboolean) v14}};
env->CallVoidMethodA(v8, mid, args);
D2C_CHECK_PENDING_EX;
#undef EX_HANDLE
}
return;
EX_UnwindBlock: return;
}
